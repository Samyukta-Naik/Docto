package com.nttdata.docto.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Service;

import com.nttdata.docto.entity.User;

@Service
public class UserDao implements IUserDao{

	JdbcTemplate template; 
	
	@Autowired
	public void setDataSource(DataSource dataSource) {
		template = new JdbcTemplate(dataSource);
	}

	@Override
	public int insertUser(String Username, String userPassword, int age, String gender, int contact, String email,
			String area, String city, int pincode) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	
	
	/*@Override
	public List<User> getUsersByLocSpec(String Username, String userPassword,int age,String gender,int contact,String email,String area,String city,int pincode) {
		return (List<User>) template.query("insert into user where specialization='"+specialization+"' and area_name='"+location+"'",new ResultSetExtractor<List<Doctor>>(){  
		    
	     public List<User> extractData(ResultSet rs) throws SQLException,  
	            DataAccessException {  
	      
	    	 
	    	 
	    	 List<User> list=new ArrayList<User>();
	    
	        while(rs.next()){ 
	        	User user=new User();  
	        	System.out.println(rs.getInt(1));
	        	user.setUserName(rs.getString(1));
	        	user.setUserPassword(rs.getString(2));
	        	user.setAge(rs.getInt(3));
	        	user.setGender(rs.getString(4));
	        	user.setContact(rs.getInt(5));
	        	user.setEmail(rs.getString(6));
	        	user.setArea(rs.getString(7));
	        	user.setCity(rs.getString(8));
	        	user.setPincode(rs.getInt(9));
	        	
	        	list.add(user);
	        	//System.out.println(e);
		        
	        }  
	        System.out.println(list);
	        return list;  
	        }  
	    });  
			
		
	}*/



}
