package com.nttdata.docto.dao;


public interface IUserDao {
	public int insertUser(String Username, String userPassword,int age,String gender,int contact,String email,String area,String city,int pincode);

}
