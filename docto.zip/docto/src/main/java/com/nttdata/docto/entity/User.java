package com.nttdata.docto.entity;

import javax.persistence.Id;
import javax.validation.constraints.NotEmpty;

public class User {
	@Id
	private int userId;
	
	@NotEmpty
	private String userName;
	
	@NotEmpty
	private String userPassword;
	
	private int age;
	
	@NotEmpty
	private String gender;

	@NotEmpty
	private int contact;
	
	private String email;
	
	@NotEmpty
	private String area;
	
	@NotEmpty
	private String city;
	
	@NotEmpty
	private int pincode;
	

	public int getUserId() {
		return userId;
	}

	/*public void setUserId(int userId) {
		this.userId = userId;
	}*/

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPasswrd) {
		this.userPassword = userPasswrd;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public int getContact() {
		return contact;
	}

	public void setContact(int contact) {
		this.contact = contact;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}
	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public int getPincode() {
		return pincode;
	}

	public void setPincode(int pincode) {
		this.pincode = pincode;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName + ", userPassword=" + userPassword + ", age=" + age
				+ ", gender=" + gender + ", contact=" + contact + ", email=" + email + ", area=" + area + ", city="
				+ city + ", pincode=" + pincode + "]";
	}

	

}
