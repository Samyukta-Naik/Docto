package com.nttdata.docto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

@SpringBootApplication
@EnableJpaAuditing
public class DoctoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DoctoApplication.class, args);
	}

}
/*
 create database docto;
use docto;
create table doctor(doctor_id int primary key,dname varchar(50),d_age int,specialization varchar(100),contact int, area_name varchar(100),location varchar(300));
insert into doctor values(101,'Natesh',50,'ENT',89564123,'pdnagar','https://goo.gl/maps/A3C2yUZXokt24XCH6');

insert into doctor values(102,'Sathish',50,'ENT',89564123,'pdnagar','https://goo.gl/maps/ABtratd4rmoAEbxj8');
create table user(user_id int AUTO_INCREMENT primary key,username varchar(50),password varchar(50),u_age int,gender varchar(50),contact_Number int, email varchar(20), area varchar(50),city varchar(50),pincode int);
drop table user;
show tables;
desc user;
select * from user;
*/